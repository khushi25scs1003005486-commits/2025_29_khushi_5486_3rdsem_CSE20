#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Book {
public:
    int id;
    string title;
    string author;
    bool issued;

    Book(int i, string t, string a) {
        id = i;
        title = t;
        author = a;
        issued = false;
    }
};

class Member {
public:
    int memberId;
    string name;

    Member(int id, string n) {
        memberId = id;
        name = n;
    }
};

class Library {
private:
    vector<Book> books;
    vector<Member> members;

public:
    void addBook() {
        int id;
        string title, author;

        cout << "\nEnter Book ID: ";
        cin >> id;
        cin.ignore();

        cout << "Enter Book Title: ";
        getline(cin, title);

        cout << "Enter Author Name: ";
        getline(cin, author);

        books.push_back(Book(id, title, author));

        cout << "Book Added Successfully!\n";
    }

    void addMember() {
        int id;
        string name;

        cout << "\nEnter Member ID: ";
        cin >> id;
        cin.ignore();

        cout << "Enter Member Name: ";
        getline(cin, name);

        members.push_back(Member(id, name));

        cout << "Member Added Successfully!\n";
    }

    void displayBooks() {
        cout << "\n------ Book List ------\n";

        if (books.empty()) {
            cout << "No Books Available.\n";
            return;
        }

        for (Book &b : books) {
            cout << "ID: " << b.id
                 << "\nTitle: " << b.title
                 << "\nAuthor: " << b.author
                 << "\nStatus: " << (b.issued ? "Issued" : "Available")
                 << "\n----------------------\n";
        }
    }

    void issueBook() {
        int id;

        cout << "\nEnter Book ID to Issue: ";
        cin >> id;

        for (Book &b : books) {
            if (b.id == id) {
                if (!b.issued) {
                    b.issued = true;
                    cout << "Book Issued Successfully!\n";
                } else {
                    cout << "Book Already Issued.\n";
                }
                return;
            }
        }

        cout << "Book Not Found.\n";
    }

    void returnBook() {
        int id;

        cout << "\nEnter Book ID to Return: ";
        cin >> id;

        for (Book &b : books) {
            if (b.id == id) {
                if (b.issued) {
                    b.issued = false;
                    cout << "Book Returned Successfully!\n";
                } else {
                    cout << "Book Was Not Issued.\n";
                }
                return;
            }
        }

        cout << "Book Not Found.\n";
    }

    void searchBook() {
        cin.ignore();

        string key;

        cout << "\nEnter Title or Author: ";
        getline(cin, key);

        bool found = false;

        for (Book &b : books) {
            if (b.title == key || b.author == key) {
                cout << "\nBook Found\n";
                cout << "ID: " << b.id << endl;
                cout << "Title: " << b.title << endl;
                cout << "Author: " << b.author << endl;
                cout << "Status: " << (b.issued ? "Issued" : "Available") << endl;

                found = true;
            }
        }

        if (!found)
            cout << "No Matching Book Found.\n";
    }
};

int main() {

    Library lib;

    int choice;

    do {
        cout << "\n====== Library Management System ======\n";
        cout << "1. Add Book\n";
        cout << "2. Add Member\n";
        cout << "3. Display Books\n";
        cout << "4. Issue Book\n";
        cout << "5. Return Book\n";
        cout << "6. Search Book\n";
        cout << "7. Exit\n";

        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                lib.addBook();
                break;

            case 2:
                lib.addMember();
                break;

            case 3:
                lib.displayBooks();
                break;

            case 4:
                lib.issueBook();
                break;

            case 5:
                lib.returnBook();
                break;

            case 6:
                lib.searchBook();
                break;

            case 7:
                cout << "Thank You!\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }

    } while (choice != 7);

    return 0;
}