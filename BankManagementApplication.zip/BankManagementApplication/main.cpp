#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Bank
{
private:
    int accNo;
    string name;
    float balance;

public:
    void createAccount()
    {
        cout << "Enter Account Number: ";
        cin >> accNo;

        cin.ignore();

        cout << "Enter Customer Name: ";
        getline(cin, name);

        cout << "Enter Initial Balance: ";
        cin >> balance;

        ofstream file("accounts.txt", ios::app);
        file << accNo << " " << name << " " << balance << endl;
        file.close();

        cout << "\nAccount Created Successfully!\n";
    }

    void deposit()
    {
        float amount;
        cout << "Enter Amount to Deposit: ";
        cin >> amount;

        balance += amount;

        cout << "Current Balance: " << balance << endl;
    }

    void withdraw()
    {
        float amount;
        cout << "Enter Amount to Withdraw: ";
        cin >> amount;

        if(amount > balance)
            cout << "Insufficient Balance!\n";
        else
        {
            balance -= amount;
            cout << "Current Balance: " << balance << endl;
        }
    }

    void checkBalance()
    {
        cout << "Balance: " << balance << endl;
    }
};

int main()
{
    Bank b;
    int choice;

    do
    {
        cout << "\n===== BANK MANAGEMENT SYSTEM =====\n";
        cout << "1. Create Account\n";
        cout << "2. Deposit\n";
        cout << "3. Withdraw\n";
        cout << "4. Check Balance\n";
        cout << "5. Exit\n";

        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                b.createAccount();
                break;

            case 2:
                b.deposit();
                break;

            case 3:
                b.withdraw();
                break;

            case 4:
                b.checkBalance();
                break;

            case 5:
                cout << "Thank You!";
                break;

            default:
                cout << "Invalid Choice!";
        }

    } while(choice != 5);

    return 0;
}